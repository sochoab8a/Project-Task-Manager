<!-- resources/views/emails/priorityTask.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Correo Básico</title>
</head>
<body>
    <h1>{{ $details['subject'] }}</h1>
    <p>{{ $details['message'] }}</p>
</body>
</html>