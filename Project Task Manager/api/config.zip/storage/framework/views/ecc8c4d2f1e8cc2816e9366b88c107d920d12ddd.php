<!-- resources/views/emails/priorityTask.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Correo Básico</title>
</head>
<body>
    <h1><?php echo e($details['subject']); ?></h1>
    <p><?php echo e($details['message']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\jwtLaravel\api\resources\views/emails/priorityTask.blade.php ENDPATH**/ ?>